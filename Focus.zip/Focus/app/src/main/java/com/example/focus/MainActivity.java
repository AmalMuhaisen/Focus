package com.example.focus;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<String> arrayList = new ArrayList<>();

    private Chronometer chronometer;
    private long stopOffset;
    private Boolean running = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);





        chronometer = findViewById(R.id.chronometer);
        //chronometer.setFormat("Time = %s");
        chronometer.setBase(SystemClock.elapsedRealtime());
        //chronometer.setCountDown();
        /*chronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                if ((SystemClock.elapsedRealtime() - chronometer.getBase()) >=1000){
                    chronometer.setBase(SystemClock.elapsedRealtime());
                    Toast.makeText(MainActivity.this, "Bing!", Toast.LENGTH_SHORT).show();
                }
            }
        }); */

        Button myli = findViewById(R.id.button3);
        myli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(MainActivity.this,MainActivity2.class);
                startActivity(in);
            }
        });

        Button li = findViewById(R.id.button6);
        li.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(MainActivity.this,MainActivity3.class);
                startActivity(in);
            }
        });

//        final EditText input = new EditText(this);
//        final EditText input2 = new EditText(MainActivity.this);
//        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
//                LinearLayout.LayoutParams.MATCH_PARENT,
//                LinearLayout.LayoutParams.MATCH_PARENT);
//        input.setLayoutParams(lp);
//        setView(input);






    }

    public void startChronometer(View v) {

       // Toast.makeText(MainActivity.this,running+"",Toast.LENGTH_LONG).show();
        if( ! running ){
           chronometer.setBase(SystemClock.elapsedRealtime() - stopOffset);
           chronometer.start();
           running = true;
        }

    }

    public void stopChronometer(View v) {
        if(running){
            chronometer.stop();
            stopOffset = SystemClock.elapsedRealtime() - chronometer.getBase();
            running = false;
            showAlert(v);
           // Toast.makeText(MainActivity.this,chronometer.getText().toString(),Toast.LENGTH_LONG).show();

        }

    }

    public void resetChronometer(View v) {
        chronometer.setBase(SystemClock.elapsedRealtime());
        stopOffset = 0;

    }

   /* public void showAlertDialogButtonClicked(View view) {
        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("AlertDialog");
        builder.setMessage("Would you like to continue learning how to use Android alerts?");
        // add the buttons
        builder.setPositiveButton("Continue", null);
        builder.setNegativeButton("Cancel", null);
        // create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    } */
   public void showAlert (View v){
       AlertDialog.Builder builder1 = new AlertDialog.Builder(this);

       final View customL = getLayoutInflater().inflate(R.layout.c_l, null);

       builder1.setView(customL);
       builder1.setMessage("Enter the info.");
       builder1.setCancelable(true);

       final EditText ahmad = customL.findViewById(R.id.edit);
       final EditText amal = customL.findViewById(R.id.edit2);
       final EditText textView = customL.findViewById(R.id.edit3);


       builder1.setPositiveButton(
               "Yes",
               new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                       dialog.cancel();
                       Intent Intent = new Intent(MainActivity.this,MainActivity2.class);
                       startActivity(Intent);

                       MainActivity.arrayList.add(ahmad.getText().toString());
                       MainActivity.arrayList.add(amal.getText().toString());
                       MainActivity.arrayList.add(textView.getText().toString());
                      // Toast.makeText(MainActivity.this,ahmad.getText().toString(),Toast.LENGTH_LONG).show();



                   }
               });

       builder1.setNegativeButton(
               "No",
               new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                       dialog.cancel();
                   }
               });

       AlertDialog alert11 = builder1.create();
       alert11.show();

   }

//   private void savaData(){
//       SharedPreferences sharedPreferences = getSharedPreferences("sharedPreferences", MODE_PRIVATE);
//       SharedPreferences.Editor editor = sharedPreferences.edit();
//      // Gson gson = new Gson;
//      // String json =gson.toJson()
//   }


}