package com.example.focus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    public static ArrayList<String> arrayList = new ArrayList<>();
    public static ArrayAdapter<String> arrayAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        arrayList = MainActivity.arrayList;



        final ListView list = findViewById(R.id.list);

//        arrayList.add(" 4/4/2020 " + "       4:50 "  +  " دراسة فيزيا ");
//        arrayList.add(" 4/12/2020 " + "      2:32 "  +  " دراسة احياء ");
//        arrayList.add(" 4/1/2020 " + "       1:51 "  + " دراسة رياضيات ");
//        arrayList.add(" 4/7/2020 " + "       7:20 "  +  " دراسة احياء ");
//        arrayList.add(" 4/8/2020 " + "       1:10 "  +  " دراسة اناتومي ");
//        arrayList.add(" 4/9/2020 " + "       30:50 "  + " دراسة كيميا ");
         arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrayList);
        list.setAdapter(arrayAdapter);

    }
}